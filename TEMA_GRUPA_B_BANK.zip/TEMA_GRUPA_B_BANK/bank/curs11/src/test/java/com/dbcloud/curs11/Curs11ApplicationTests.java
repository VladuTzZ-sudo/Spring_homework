package com.dbcloud.curs11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Curs11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
